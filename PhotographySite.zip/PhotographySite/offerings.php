
<!DOCTYPE html>
<html lang="en">
<head>
<title>Cage the Moment Photography</title>
<meta charset="utf-8">
<link rel="stylesheet" href="style.css">
</head>

<body>
<div id="wrapper">

<?php
  include 'header.php';
  include 'nav.php';
?>

  <main>

    <img class="floatright" src="Pictures/StillThumbnail6.jpg" alt="Portraits" width="300" height="200">

      <h2>Offerings</h2>

      <table>
        <tr><td>1 hour portrait session with 5 digital prints</td><td>$100</td></tr>
        <tr><td>1 hour portrait session with 10 digital prints</td><td>$150</td></tr>
        <tr><td>2 hour portrait session with 20 digital prints</td><td>$200</td></tr>
        <tr><td>3 hour event with 20 digital prints</td><td>$300</td></tr>
        <tr><td>3 hour event with 20 digital prints and album</td><td>$500</td></tr>
      </table>

      <br><br>

    </main>

<?php
	include 'footer.php';
?>

</div>
</body>
</html>


