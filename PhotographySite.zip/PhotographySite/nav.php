<!doctype html>
<html>
<body>
<?php

  echo '<nav>
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="about.php">About</a></li>
      <li><a href="gallery.php">Gallery</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="offerings.php">Offerings</a></li>
	</ul>
  </nav>';
  
?>
</body>
</html>