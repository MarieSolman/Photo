<!DOCTYPE html>
<html lang="en">
<head>
	<title>Submission Complete-</title>
	<meta charset="utf-8">
	<link rel="stylesheet" href="style.css">
</head>	
<body>

<div id="wrapper">
<?php // sqltest.php

  include 'header.php';
  include 'nav.php';

  require_once 'login.php';
  $conn = new mysqli($hn, $un, $pw, $db);
  if ($conn->connect_error) die($conn->connect_error);

  if (isset($_POST['myFirstName']) &&
      isset($_POST['myLastName']) &&
      isset($_POST['myAddress']) &&
      isset($_POST['myCity']))
  {
    $myFirstName = get_post($conn, 'myFirstName');
	$myLastName = get_post($conn, 'myLastName');
	$myAddress = get_post($conn, 'myAddress');
	$myCity = get_post($conn, 'myCity');
	$myState = get_post($conn, 'myState');
	$myZip = get_post($conn, 'myZip');
	$myEmail = get_post($conn, 'myEmail');
	$myComment = get_post($conn, 'myComment');
	
    $query = "INSERT INTO clients VALUES(NULL,'$myFirstName', '$myLastName', '$myAddress', '$myCity', '$myState', '$myZip', '$myEmail', '$myComment')";
    
	$result = $conn->query($query);

  	if (!$result)
	{
		echo "INSERT failed: $query<br>" . $conn->error . "<br><br>";
	}	
	else
	{
		echo "<main>";
		echo "<h1> Thank you for your submission: </h1><br>";
		echo "First Name: " . $myFirstName . "<br>";
		echo "Last Name: " . $myLastName . "<br>";
		echo "Address: " . $myAddress . "<br>";
		echo "City: " . $myCity . "<br>";
		echo "State: " . $myState . "<br>";
		echo "Zip Code: " . $myZip . "<br>";
		echo "Email: " . $myEmail . "<br>";
		echo "Comments: " . $myComment . "<br><br><br>";
		echo "</main>";
	}
  }
  
  $conn->close();
  
  function get_post($conn, $var)
  {
    return $conn->real_escape_string($_POST[$var]);
  }

	include 'footer.php';
  
?>

</div>
</body>
