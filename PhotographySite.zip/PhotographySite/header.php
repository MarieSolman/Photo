<!doctype html>
<html>
<body>
<?php

  echo '<header>
    <h1>Cage the Moment Photography</h1>
	<div id="tagline">Portraits, Events, and More</div>
  </header>';
  
?>
</body>
</html>