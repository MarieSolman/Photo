<!doctype html>
<html>
<body>
<?php

  echo '<footer>Copyright &copy; 2016</footer>';
  
?>
</body>
</html>