<?php // login.php

  $hn = 'localhost';

  $db = 'photography';

  $un = 'PHOTO_USER';

  $pw = 'PHPISFUN';
?>
