
<!DOCTYPE html>
<html lang="en">
<head>
<title>Cage the Moment Photography</title>
<meta charset="utf-8">
<link rel="stylesheet" href="style.css">
</head>

<body>
<div id="wrapper">

<?php
  include 'header.php';
  include 'nav.php';
?>

  <main>
      <img src="Pictures/Landscape1.jpg" alt="Make a moment last forever" style="width:720px;height:480px;">
    </main>

<?php
	include 'footer.php';
?>

</div>
</body>
</html>


