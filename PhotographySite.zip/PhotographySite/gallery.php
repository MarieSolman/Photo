
<!DOCTYPE html>
<html lang="en">
<head>
<title>Cage the Moment Photography</title>
<meta charset="utf-8">
<link rel="stylesheet" href="style.css">
</head>

<body>
<div id="wrapper">

<?php
  include 'header.php';
  include 'nav.php';
?>

  <main>
      <h2>Gallery</h2>

		<div class="img">
  <a href="portraits.php">
    <img src="Pictures/PortraitThumbnail23.jpg" alt="Portraits" width="300" height="200">
  </a>
  <div class="desc">Portraits</div>
</div>

<div class="img">
  <a href="still.php">
    <img src="Pictures/StillThumbnail1.jpg" alt="Still Life" width="300" height="200">
  </a>
  <div class="desc">Still Life</div>
</div>

<div class="img">
  <a href="landscapes.php">
    <img src="Pictures/LandscapeThumbnail6.jpg" alt="Landscapes" width="300" height="200">
  </a>
  <div class="desc">Landscapes</div>
</div>


    </main>

<?php
	include 'footer.php';
?>

</div>
</body>
</html>


