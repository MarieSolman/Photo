
<!DOCTYPE html>
<html lang="en">
<head>
<title>Cage the Moment Photography</title>
<meta charset="utf-8">
<link rel="stylesheet" href="style.css">
</head>

<body>
<div id="wrapper">

<?php
  include 'header.php';
  include 'nav.php';
?>

  <main>

    <img class="floatright" src="Pictures/Landscape5.jpg" alt="Portraits" width="360" height="240">

      <h2>About</h2>

    <p>
      I am a hobbyist photographer from the greater Boston area pursuing my passion for visual arts and desire to preserve fond memories. Cage the Moment Photography is both a portfolio and a demonstration of services. I offer solo and group portraits, event photography, and headshots. Contact me using any of the methods listed below to discuss rates and availability!
    </p>

    <br><br><br><br><br><br>

    </main>

<?php
	include 'footer.php';
?>

</div>
</body>
</html>


