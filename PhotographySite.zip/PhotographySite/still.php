
<!DOCTYPE html>
<html lang="en">
<head>
<title>Cage the Moment Photography</title>
<meta charset="utf-8">
<link rel="stylesheet" href="style.css">
</head>

<body>
<div id="wrapper">

<?php
  include 'header.php';
  include 'nav.php';
?>

  <main>

    <a href="gallery.php">Return to gallery</a>

      <h2>Still Life</h2>

        <div class="img">
          <a target="_blank" href="Pictures/Still1.jpg">
            <img src="Pictures/StillThumbnail1.jpg" alt="Still Life" width="300" height="200">
          </a>
        </div>

        <div class="img">
          <a target="_blank" href="Pictures/Still2.jpg">
            <img src="Pictures/StillThumbnail2.jpg" alt="Still Life" width="300" height="200">
          </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Still3.jpg">
           <img src="Pictures/StillThumbnail3.jpg" alt="Still Life" width="300" height="200">
         </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Still4.jpg">
           <img src="Pictures/StillThumbnail4.jpg" alt="Still Life" width="300" height="200">
         </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Still5.jpg">
           <img src="Pictures/StillThumbnail5.jpg" alt="Still Life" width="300" height="200">
         </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Still6.jpg">
           <img src="Pictures/StillThumbnail6.jpg" alt="Still Life" width="300" height="200">
         </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Still7.jpg">
           <img src="Pictures/StillThumbnail7.jpg" alt="Still Life" width="300" height="200">
         </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Still8.jpg">
           <img src="Pictures/StillThumbnail8.jpg" alt="Still Life" width="300" height="200">
         </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Still9.jpg">
           <img src="Pictures/StillThumbnail9.jpg" alt="Still Life" width="300" height="200">
         </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Still10.jpg">
           <img src="Pictures/StillThumbnail10.jpg" alt="Still Life" width="300" height="200">
         </a>
        </div>


    </main>

<?php
	include 'footer.php';
?>

</div>
</body>
</html>


