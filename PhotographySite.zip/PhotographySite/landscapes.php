
<!DOCTYPE html>
<html lang="en">
<head>
<title>Cage the Moment Photography</title>
<meta charset="utf-8">
<link rel="stylesheet" href="style.css">
</head>

<body>
<div id="wrapper">

<?php
  include 'header.php';
  include 'nav.php';
?>

  <main>

    <a href="gallery.php">Return to gallery</a>

      <h2>Landscapes</h2>

        <div class="img">
          <a target="_blank" href="Pictures/Landscape1.jpg">
            <img src="Pictures/LandscapeThumbnail1.jpg" alt="Landscape" width="300" height="200">
          </a>
        </div>

        <div class="img">
          <a target="_blank" href="Pictures/Landscape2.jpg">
            <img src="Pictures/LandscapeThumbnail2.jpg" alt="Landscape" width="300" height="200">
          </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Landscape3.jpg">
           <img src="Pictures/LandscapeThumbnail3.jpg" alt="Landscape" width="300" height="200">
         </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Landscape4.jpg">
           <img src="Pictures/LandscapeThumbnail4.jpg" alt="Landscape" width="300" height="200">
         </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Landscape5.jpg">
           <img src="Pictures/LandscapeThumbnail5.jpg" alt="Landscape" width="300" height="200">
         </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Landscape6.jpg">
           <img src="Pictures/LandscapeThumbnail6.jpg" alt="Landscape" width="300" height="200">
         </a>
        </div>

        <div class="img">
         <a target="_blank" href="Pictures/Landscape7.jpg">
           <img src="Pictures/LandscapeThumbnail7.jpg" alt="Landscape" width="300" height="200">
         </a>
        </div>


    </main>

<?php
	include 'footer.php';
?>

</div>
</body>
</html>


